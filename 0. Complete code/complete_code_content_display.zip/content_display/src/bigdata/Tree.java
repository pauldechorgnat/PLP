package bigdata;

import java.util.ArrayList;

public class Tree {
	// GEOPOINT;ARRONDISSEMENT;GENRE;ESPECE;FAMILLE;ANNEE PLANTATION;HAUTEUR;CIRCONFERENCE;
	// ADRESSE;NOM COMMUN;VARIETE;OBJECTID;NOM_EV
	private String geopoint;
	private Integer arrondissement;
	private String genre;
	private String species;
	private String family;
	private Integer year;
	private String plantation;
	private Double height;
	private Double circumference;
	private String address;
	private String name;
	private String variety;
	private String objectID;
	private String name_EV;
	
	public String getGeopoint() {
		return geopoint;
	}
	public void setGeopoint(String geopoint) {
		this.geopoint = geopoint;
	}
	public Integer getArrondissement() {
		return arrondissement;
	}
	public void setArrondissement(Integer arrondissement) {
		this.arrondissement = arrondissement;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public String getSpecies() {
		return species;
	}
	public void setSpecies(String species) {
		this.species = species;
	}
	public String getFamily() {
		return family;
	}
	public void setFamily(String family) {
		this.family = family;
	}
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	public String getPlantation() {
		return plantation;
	}
	public void setPlantation(String plantation) {
		this.plantation = plantation;
	}
	public Double getCircumference() {
		return circumference;
	}
	public void setCircumference(Double circumference) {
		this.circumference = circumference;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getVariety() {
		return variety;
	}
	public void setVariety(String variety) {
		this.variety = variety;
	}
	public String getObjectID() {
		return objectID;
	}
	public void setObjectID(String objectID) {
		this.objectID = objectID;
	}
	public String getName_EV() {
		return name_EV;
	}
	public void setName_EV(String name_EV) {
		this.name_EV = name_EV;
	}
	public Double getHeight() {
		return height;
	}
	public void setHeight(Double height) {
		this.height = height;
	}

	
	public Tree(String geopoint, Integer arrondissement, String genre, String species, String family, Integer year,
			String plantation, Double height, Double circumference, String address, String name, String variety,
			String objectID, String name_EV) {
		super();
		this.geopoint = geopoint;
		this.arrondissement = arrondissement;
		this.genre = genre;
		this.species = species;
		this.family = family;
		this.year = year;
		this.plantation = plantation;
		this.height = height;
		this.circumference = circumference;
		this.address = address;
		this.name = name;
		this.variety = variety;
		this.objectID = objectID;
		this.name_EV = name_EV;
	}
	
	
	public static ArrayList<String> parseString(String line) {
		ArrayList<String> values_to_return = new ArrayList<String>();
		String splits[] = line.split(";");
		// if the line is a line of data
		if(!splits[0].equals("GEOPOINT")) {
			String height = splits[7];
			String age = splits[5];
			if(height.length()==0) {
				height = "<missing>";
			}
			if(age.length()==0) {
				age = "<missing>";
			}
			values_to_return.add(height);
			values_to_return.add(age);
		}
		return values_to_return;
	}
}
