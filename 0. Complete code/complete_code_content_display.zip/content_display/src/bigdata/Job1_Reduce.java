package bigdata;


import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;

public class Job1_Reduce extends Reducer<NullWritable,Text,NullWritable,Text> {

    @Override
    protected void reduce(NullWritable key, Iterable<Text> list_data, Context context) throws IOException,InterruptedException
    {
    	for(Text value: list_data) {
    		context.write(NullWritable.get(), value);
    	}
    }

}
