package bigdata;


import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;
import java.util.ArrayList;


public class Job1_Map extends Mapper<LongWritable, Text, NullWritable, Text> {

	@Override
	protected void map(LongWritable keyE, Text line, Context context) throws IOException,InterruptedException
	    {
			ArrayList<String> data = Tree.parseString(line.toString());
			if(data.size()==2) {
				context.write(NullWritable.get(), new Text("height : "+ data.get(0) + "\tage : "+data.get(1)));
			}
	    }
	public void run(Context context) throws IOException, InterruptedException {
	    setup(context);
	    while(context.nextKeyValue()){
	        map(context.getCurrentKey(), context.getCurrentValue(), context);
	    }
	    cleanup(context);
	}
}






