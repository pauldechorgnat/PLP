package bigdata;


import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;


public class Job2_Map extends Mapper<LongWritable, Text, Text, Text> {

	@Override
	protected void map(LongWritable key, Text start___number_tab_end, Context context) throws IOException,InterruptedException
	    {
			// Splitting the input line 
			String[] start___number_end_splitted = start___number_tab_end.toString().split("\t");
			Text start_number = new Text(start___number_end_splitted[0]);
			Text end = new Text(start___number_end_splitted[1]);
			context.write(start_number, end);
	    }
	public void run(Context context) throws IOException, InterruptedException {
	    setup(context);
	    while(context.nextKeyValue()){
	        map(context.getCurrentKey(), context.getCurrentValue(), context);
	    }
	    cleanup(context);
	}
}






