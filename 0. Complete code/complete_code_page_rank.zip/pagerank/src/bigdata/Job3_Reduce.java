package bigdata;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Job3_Reduce extends Reducer<Text,Text,Text,Text> {

    @Override
    protected void reduce(Text node, Iterable<Text> node_information, Context context) throws IOException,InterruptedException
    {
    	// Initiating some variables
    	Double other_nodes_contribution = 0.;
    	String list_of_ends = "";
    	Double damping_factor = .85;
    	Double number_of_nodes = 0.;
    	Double number_of_outgoing_nodes = 0. ;
    	Text start = new Text();
    	
    	Iterator<Text> iterator = node_information.iterator();
    	
    	while(iterator.hasNext()) {
    		
    		String value = iterator.next().toString();
    		
    		if(value.substring(0, 2).equals("->")) { // in the case the node is seen as a start node
    		
    			list_of_ends =value;
    			start = node;
    			number_of_nodes = Double.valueOf(node.toString().split("_")[1]);    			
    		
    		} else {//if (value.substring(0,2).equals("::")) { // in the case the node is seen as a end node
    		
    			String[] splits = value.substring(2).split("<-");
    			String[] splits2 = splits[1].split(",");
    			Double pagerank = Double.valueOf(splits[0]);
    			number_of_outgoing_nodes = Double.valueOf(splits2[1]);
    			
    			// updating other nodes contribution
    			other_nodes_contribution +=pagerank/number_of_outgoing_nodes;
    			
    		}
    	}
    	Double new_page_rank = damping_factor*other_nodes_contribution + (1-damping_factor)/number_of_nodes;
    	
    	// emit values only if the node matches the right pattern
    	Pattern pattern = Pattern.compile("[0-9]+_[0-9]+");
		Matcher matcher = pattern.matcher((CharSequence) start.toString());
		boolean b = matcher.find();
    	if(b) {
    		context.write(start, new Text(new_page_rank.toString() + list_of_ends));
    	}
    }

}
