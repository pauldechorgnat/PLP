package bigdata;


import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class Job1_Reduce extends Reducer<Text,Text,Text,Text> {

    @Override
    protected void reduce(Text new_line, Iterable<Text> list_of_lines, Context context) throws IOException,InterruptedException
    {
    	HashMap<String, Integer>  dictionnary_of_nodes = new HashMap<String, Integer>();
    	Integer number_of_nodes = 0;
    	ArrayList<String> lines = new ArrayList<String>();
        Iterator<Text> iterator = list_of_lines.iterator();
        
        while(iterator.hasNext()){
        	// Getting the new value
        	String line_string = iterator.next().toString();
        	// Adding the new line to the list of lines
        	lines.add(line_string);
        	// Splitting the line to get the nodes
        	String[] splits = line_string.split("\t");
        	String node_1 = splits[0];
        	String node_2 = splits[1];
        	// Putting the nodes into the HashMap
        	dictionnary_of_nodes.put(node_1, 1);
        	dictionnary_of_nodes.put(node_2, 1);
        }
        // Getting the number of nodes
        number_of_nodes = dictionnary_of_nodes.keySet().size();
        
        for(String line: lines) {
        	// Getting the nodes
        	String[] splits = line.split("\t");
        	String start = splits[0];
        	String end = splits[1];
        	// Emitting the values
        	context.write(new Text(start + "_" + number_of_nodes.toString()), new Text(end+ "_" + number_of_nodes.toString()));
        }
    }

}
