package bigdata;


import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;
import java.util.TreeMap;


public class Job4_Map extends Mapper<LongWritable, Text, NullWritable, Text> {
	private TreeMap<Double, Text>  repToRecordMap = new TreeMap<Double, Text>();
	@Override
	protected void map(LongWritable keyE, Text valE, Context context) throws IOException,InterruptedException
	    {	
			// parsing data
			String splits[] = valE.toString().split("\t|_|->");
			Text node_score = new Text(splits[0]+  " " + splits[2]);
			Double pagerank = Double.parseDouble(splits[2]);
			
			// storing the values into a TreeMap
			repToRecordMap.put(pagerank, node_score);
			
			// removing the first value if the size exceeds 20
			if(repToRecordMap.size()>20) {
				repToRecordMap.remove(repToRecordMap.firstKey());
			}
	    }
	
	protected void cleanup(Context context) throws IOException, InterruptedException {
		for (Text t : repToRecordMap.values()) {
			context.write(NullWritable.get(), t);
		}
	}
	
	public void run(Context context) throws IOException, InterruptedException {
	    setup(context);
	    while(context.nextKeyValue()){
	        map(context.getCurrentKey(), context.getCurrentValue(), context);
	    }
	    cleanup(context);
	}
}






