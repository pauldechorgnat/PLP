package bigdata;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class Job3_Driver extends Configured implements Tool {


    public int run(String[] paths) throws Exception {
    	String inpath = paths[0];
    	String outpath = paths[1];
 

        Job job = Job.getInstance(getConf()); 
        job.setJobName("page rank third step");

        job.setJarByClass(Job3_Driver.class);
        job.setMapperClass(Job3_Map.class);
        job.setReducerClass(Job3_Reduce.class);

        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        FileInputFormat.addInputPath(job, new Path(inpath));
        FileOutputFormat.setOutputPath(job, new Path(outpath));

        FileSystem fs = FileSystem.newInstance(getConf());

        if (fs.exists(new Path(inpath))) {
            fs.delete(new Path(outpath), true);
        }

        return job.waitForCompletion(true) ? 0: 1;

    }
    public static void main(String[] args) throws Exception {
    	 // Configuration conf = new Configuration();

    	if (args.length != 3) {
    	  System.err.println("Usage: wordcount <in> <out> <iterations>");
    	  System.exit(2);
    	}
    	int iterations = new Integer(args[2]);
    	Path inPath = new Path(args[0]);
    	Path outPath =  null;
    	int res = 0;
    	for (int i = 0; i<iterations; ++i){
    	    outPath = new Path(args[1]+i );
            Job3_Driver exempleDriver = new Job3_Driver();
            String[] paths = {inPath.toString(), outPath.toString()};
            res = ToolRunner.run(exempleDriver, paths);
            
    	    inPath = new Path(outPath.toString()+ "/part-r-00000");
    	   }

        System.exit(res);
    	 }
}

