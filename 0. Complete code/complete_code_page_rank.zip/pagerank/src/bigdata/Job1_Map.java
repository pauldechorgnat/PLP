package bigdata;


import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Job1_Map extends Mapper<LongWritable, Text, Text, Text> {

	@Override
	protected void map(LongWritable keyE, Text valE, Context context) throws IOException,InterruptedException
	    {
			Pattern pattern = Pattern.compile("[0-9]+\t[0-9]+");
			Matcher matcher = pattern.matcher((CharSequence) valE.toString());
			boolean b = matcher.find();
			
			if(b) {
				context.write(new Text("new_line"), valE);
			}
	    }
	public void run(Context context) throws IOException, InterruptedException {
	    setup(context);
	    while(context.nextKeyValue()){
	        map(context.getCurrentKey(), context.getCurrentValue(), context);
	    }
	    cleanup(context);
	}
}






