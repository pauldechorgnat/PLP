package bigdata;


import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.TreeMap;

public class Job4_Reduce extends Reducer<NullWritable,Text,NullWritable,Text> {

	private TreeMap<Double, Text> repToRecordMap = new TreeMap<Double, Text>();
	
	public void reduce(NullWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
	
		for (Text value : values) {

			repToRecordMap.put(Double.parseDouble(value.toString().split(" ")[1]),	new Text(value.toString().replaceAll(" ","\t")));
			
			if (repToRecordMap.size() > 20) {
				
				repToRecordMap.remove(repToRecordMap.firstKey());
				}
			}
	for (Text t : repToRecordMap.descendingMap().values()) {
	// Output our ten records to the file system with a null key
		context.write(NullWritable.get(), t);
	}
	}
}
