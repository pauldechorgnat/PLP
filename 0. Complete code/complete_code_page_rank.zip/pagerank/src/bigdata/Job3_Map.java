package bigdata;


import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Job3_Map extends Mapper<LongWritable, Text, Text, Text> {

	@Override
	protected void map(LongWritable key, Text line, Context context) throws IOException,InterruptedException
	    {
			// Splitting the input line 
			// The input looks like 
			// start\tpagerankscore->end1,end2,end3, ...
			Pattern pattern = Pattern.compile("^[0-9]+");
			Matcher matcher = pattern.matcher((CharSequence) line.toString());
			boolean b = matcher.find();
		
			if(b) {
				
				String[] splits1 = line.toString().split("\t");
				String start_number = splits1[0];
				String[] splits2 = splits1[1].split("->");
				String pagerank_score = splits2[0];
				String[] list_of_ends = splits2[1].split(",");
				// emitting end nodes for each of the starting node
				for(String end:list_of_ends) {
					context.write(new Text(end), new Text("::" + pagerank_score + "<-" + start_number + ","  + list_of_ends.length));
				}
				// emitting start nodes with their list of end nodes
				context.write(new Text(start_number), new Text("->"+splits2[1]));
		    }
	    }
	
	public void run(Context context) throws IOException, InterruptedException {
	    setup(context);
	    while(context.nextKeyValue()){
	        map(context.getCurrentKey(), context.getCurrentValue(), context);
	    }
	    cleanup(context);
	}
}






