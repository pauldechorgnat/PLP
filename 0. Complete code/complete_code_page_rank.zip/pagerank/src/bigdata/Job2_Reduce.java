package bigdata;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.Iterator;

public class Job2_Reduce extends Reducer<Text,Text,Text,Text> {

    @Override
    protected void reduce(Text start_number, Iterable<Text> list_of_lines, Context context) throws IOException,InterruptedException
    {
    
        Iterator<Text> iterator = list_of_lines.iterator();
        
        Double number = 1./Double.parseDouble(start_number.toString().split("_")[1]);
        
        String list_of_ends = number.toString() + "->";
        while(iterator.hasNext()) {
        	list_of_ends += iterator.next().toString() + ","; 
        }
        context.write(start_number, new Text(list_of_ends));
    }

}
