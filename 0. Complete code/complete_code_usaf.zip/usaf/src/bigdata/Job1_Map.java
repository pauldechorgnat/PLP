package bigdata;


import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;


public class Job1_Map extends Mapper<LongWritable, Text, Text, Text> {

	@Override
	protected void map(LongWritable key_doc, Text text_doc, Context context) throws IOException,InterruptedException
	    {
	        // splitting the line
			String line_string = text_doc.toString();
			if(line_string.length() == 99) {
				String name = line_string.substring(13, 13+29);
				String fips = line_string.substring(43, 43+2);
				String alti = line_string.substring(74, 74+7);
				context.write(new Text(name), new Text("FIPS : "+ fips +"\taltitude : "+ alti));
			}
	        
	    }
	public void run(Context context) throws IOException, InterruptedException {
	    setup(context);
	    while(context.nextKeyValue()){
	        map(context.getCurrentKey(), context.getCurrentValue(), context);
	    }
	    cleanup(context);
	}
}






