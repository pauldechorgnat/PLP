package bigdata;


import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;

public class Job1_Reduce extends Reducer<Text,Text,Text,Text> {


    // Overriding of the reduce function
    protected void reduce(Text name, Iterable<Text> list_data, Context context) throws IOException,InterruptedException

    {    	
    	for(Text data : list_data) {
    		context.write(name, data);
    		}
    	}
}
