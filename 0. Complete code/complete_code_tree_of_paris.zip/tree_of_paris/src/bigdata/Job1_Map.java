package bigdata;


import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;


public class Job1_Map extends Mapper<LongWritable, Text, Text, Text> {

	@Override
	protected void map(LongWritable key_doc, Text text_doc, Context context) throws IOException,InterruptedException
	    {
	        // splitting the line
			String splits[] = text_doc.toString().split(";");
			
			
	        if(!splits[0].equals("GEOPOINT")) {

		        Text height= new Text(splits[7]);
		        Text type = new Text(splits[2]);
	        	context.write(type, height);
	        }
	        
	    }
	public void run(Context context) throws IOException, InterruptedException {
	    setup(context);
	    while(context.nextKeyValue()){
	        map(context.getCurrentKey(), context.getCurrentValue(), context);
	    }
	    cleanup(context);
	}
}






