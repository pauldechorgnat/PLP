package bigdata;


import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;

public class Job1_Reduce extends Reducer<Text,Text,Text,Text> {


    // Overriding of the reduce function
    protected void reduce(Text type, Iterable<Text> list_trees_heights, Context context) throws IOException,InterruptedException

    {
    	Double max_height = 0.;
    	Integer number_of_trees = 0;
    	
    	for(Text value : list_trees_heights) {
    		//Updating the maximum height
    		if(value.toString().length()>0) {
    		Double height = Double.parseDouble(value.toString());
    		if(max_height < height) {
    			max_height = height;
    		}
    		number_of_trees +=1;
    	}
    	}
    	context.write(new Text(type), new Text("Max Height : "+ max_height.toString() + "\tNumber of trees : "+ number_of_trees.toString()));

}

}
