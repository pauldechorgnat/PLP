package bigdata;


import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.Iterator;

public class Job1_Reduce extends Reducer<Text,IntWritable,Text,IntWritable> {


    // Overriding of the reduce function
    protected void reduce(Text doc_word, Iterable<IntWritable> list_instances, Context context) throws IOException,InterruptedException

    {
    	// creating output key
        Text doc_word_output = doc_word;

        Iterator<IntWritable> iterator = list_instances.iterator();
        int sum = 0;
        // running through the values and computing total number
        while (iterator.hasNext()) {
            sum += iterator.next().get();
        }
        IntWritable total_sum = new IntWritable();
        total_sum.set(sum);
        context.write(doc_word_output, total_sum);

}

}
