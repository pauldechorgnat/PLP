package bigdata;


import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;


public class Job1_Map extends Mapper<LongWritable, Text, Text, IntWritable> {

	@Override
	protected void map(LongWritable key_doc, Text text_doc, Context context) throws IOException,InterruptedException
	    {
	        // splitting text
	        StringTokenizer itr = new StringTokenizer(text_doc.toString());
	          
	        Text word = new Text();
	        IntWritable val_one = new IntWritable(1);
	        String fileName = ((FileSplit) context.getInputSplit()).getPath().getName();

	       
	        Text doc_id = new Text();
	        doc_id.set(fileName);
	        
	        
	        while(itr.hasMoreTokens()){
	            // creating key and values
	            word.set(itr.nextToken());
	            Text doc_word = new Text();
	            
	            doc_word.set(doc_id + "@" + word);
	            
	            // emiting values
	            context.write(doc_word,val_one);            
	        }
	    }
	public void run(Context context) throws IOException, InterruptedException {
	    setup(context);
	    while(context.nextKeyValue()){
	        map(context.getCurrentKey(), context.getCurrentValue(), context);
	    }
	    cleanup(context);
	}
}






