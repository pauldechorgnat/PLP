package bigdata;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Job3_Reduce extends Reducer<Text,Text,Text,DoubleWritable> {

    @Override
    protected void reduce(Text keyI, Iterable<Text> listevalI, Context context) throws IOException,InterruptedException

    {
    	int numberOfDocs = 0;

    	String word = keyI.toString();
    	
    	
    	Map<String, Double>  dictionnary = new HashMap<String, Double>();
    	
        // for a given word there are the same number of elements in
        for(Text value : listevalI){
        	//updating the number of docs
        	numberOfDocs += 1;
             	
        	// splitting the value (Reminder: "word@wordcount@wordsperdoc")
        	String[] splits = value.toString().split("@");
        	
        	String doc_id = splits[0];
        	Double wordcount = Double.parseDouble(splits[1]);
        	Double wordsperdoc = Double.parseDouble(splits[2]);
        	
        	// storing values
        	dictionnary.put(word + "@" + doc_id, wordcount/wordsperdoc);
        	
        	
        }
        for (String key : dictionnary.keySet()){
        	
        	Double idf = Math.log(2./numberOfDocs);
        	DoubleWritable tfIDF = new DoubleWritable();
        	tfIDF.set(dictionnary.get(key)*idf);
        	
        	Text keyOutput = new Text();
        	keyOutput.set(key);
        	
        	context.write(keyOutput, tfIDF);
        }
}

}
