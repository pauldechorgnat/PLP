package bigdata;


import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;


public class Job2_Map extends Mapper<LongWritable, Text, Text, Text> {

	@Override
	protected void map(LongWritable keyE, Text doc_word_count, Context context) throws IOException,InterruptedException
	    {
			// splitting text
			String[] splits = doc_word_count.toString().split("\t|@");
			Text doc = new Text();
	    	doc.set(splits[0]);
	    	Text word_count = new Text();
	    	word_count.set(splits[1]+"@"+splits[2]);
	    	context.write(doc, word_count);
	    }
	public void run(Context context) throws IOException, InterruptedException {
		setup(context);
		while(context.nextKeyValue()){
			map(context.getCurrentKey(), context.getCurrentValue(), context);
		}
		cleanup(context);
}
}






