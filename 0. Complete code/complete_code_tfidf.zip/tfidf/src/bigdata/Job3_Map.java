package bigdata;


import org.apache.hadoop.io.*;        
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;


public class Job3_Map extends Mapper<LongWritable, Text, Text, Text> {

	@Override
	protected void map(LongWritable keyE, Text valE, Context context) throws IOException,InterruptedException
	    {
			// splitting text
			String[] splits = valE.toString().split("\t|@");
			String word = splits[0];
			String doc_id = splits[1];
			String wordCount = splits[2];
			String wordsPerDoc = splits[3];
			
			// Setting the key to word
			Text keyI = new Text();
	    	keyI.set(word);
	    	
	    	// Setting the value that is going to be 
	    	// doc_id@word_count@words_per_doc
	    	Text valI = new Text();
	    	valI.set(doc_id+"@" + wordCount+ "@" + wordsPerDoc);
	    	
	    	//emit results
	    	context.write(keyI, valI);
	    }
	public void run(Context context) throws IOException, InterruptedException {
		setup(context);
		while(context.nextKeyValue()){
			map(context.getCurrentKey(), context.getCurrentValue(), context);
		}
		cleanup(context);
}
}






