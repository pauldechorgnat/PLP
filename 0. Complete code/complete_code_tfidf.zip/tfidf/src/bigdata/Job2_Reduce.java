package bigdata;

import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Job2_Reduce extends Reducer<Text,Text,Text,Text> {

    @Override
    protected void reduce(Text keyI, Iterable<Text> listevalI, Context context) throws IOException,InterruptedException
    {
    	// initializing the number of words in the document
        int numberOfWords = 0;
        // initializing a dictionary to count the number of instances of a given word into the doc
        Map<String, Integer> dictionary = new HashMap<String, Integer>();
        
        String doc_id = keyI.toString();
        
        // running through the word count of a given document
        for(Text wordNumber : listevalI){
        	
        	// splitting the value (Reminder: "word@number")
        	String[] wordNumberSplits = wordNumber.toString().split("@");
        	String word = wordNumberSplits[0];
        	Integer wordcount = Integer.parseInt(wordNumberSplits[1]);
        	
        	// updating dictionary
        	dictionary.put(word, wordcount);
        	// updating the number of the number of words
        	numberOfWords += wordcount;
        }
        // running through the words that were in the document
        for(String word : dictionary.keySet()){
        	
        	// building the new key "word@doc_id"
        	Text keyS = new Text(word + "@" + doc_id);
        	
        	// emitting the values "wordcount@wordsperdoc"
        	context.write(keyS, new Text(dictionary.get(word)+ "@" + String.valueOf(numberOfWords)));
        }

}
}
